#!/bin/sh
cd /home/orangepi/web_controller_release_1_0
/usr/bin/python3 /home/orangepi/web_controller_release_1_0/main.py > main.log &