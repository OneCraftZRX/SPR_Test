#!/bin/sh
cd /home/orangepi/web_controller
/usr/bin/python3 main.py > main.log &

